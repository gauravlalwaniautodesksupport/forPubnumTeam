# UDA Notifications

## Description

This package handles UDA Notifications. The package provide capability to interact with PubNub and provide a mechanism to consume/publish local notification

## How to use this

to be Updated after first use

##About INotification abstract class (INotification)
Intitialize INotification Implementor

```javascript
    abstract initialize(): void;
```

Subscribe to notification on the basis EventTpe and EntityId. On Successfull subscription, subscription id will be provided to consumer

```javascript
  subscribe(
    entityId: string,
    eventType: NotificationType,
    callback: (...args) => void,
    componentIdentifier: string
): string
```

Delete a subscription

```javascript
  public abstract unSubscribe(
    subscriberId: string,
    entityId: string,
    context: string
): void;
```

Unsubscribe to all subscription

```javascript
   public abstract unsubscribeAll(): void
```

Publishing Events

```javascript
    public abstract publishEvents(
    entityId: string,
    eventType: NotificationType,
    data: any
): void;
```

Validating INotification Initialization

```javascript
    public abstract validateInititalization(): boolean;
```
