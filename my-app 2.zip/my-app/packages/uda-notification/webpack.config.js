const common = require('../../webpack.config');
const path = require('path');
const { merge } = require('webpack-merge');

module.exports = merge(common(), {
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: 'uda-notification.[name].bundle.js',
    library: 'UDANotification',
    libraryTarget: 'umd',
  },
});
