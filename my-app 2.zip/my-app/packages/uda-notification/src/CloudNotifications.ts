import { PubNubWrapper } from './PubNubWrapper';
import { Subscriber, PubNubSubscription } from './model/ISubscription';
import { INotification, NotificationType } from './model/INotification';
import {v4 as uuidv4} from 'uuid';


export class CloudNotifications implements INotification {
  private pubNubHelper: PubNubWrapper;
  private isInitialized: boolean;
  private subscribers = new Map<string, Subscriber[]>();
  constructor() {
    this.pubNubHelper = new PubNubWrapper();
    this.isInitialized = false;
    this.pubNubMessageAggregator = this.pubNubMessageAggregator.bind(this);
  }
  /**
   * Initializing pubNub here
   */
  public initialize() {
    this.pubNubHelper.initializePuNub(this.pubNubHelper.getPubnubCredentials());
    this.isInitialized = true;
  }
  /**
   * subscribe to Notification Service.
   * @param {entityId} The unique Identifier
   * @param {eventType} The notification type like files Added, File Modified etc
   * @param {callback} The callback method passed by consumer
   * @param {componentIdentifier} Component unique identifier
   * @return {string} The subscriber id will be returned
   */
  public subscribe(
    entityId: string,
    eventType: NotificationType,
    callback: (...args) => void,
    componentIdentifier: string
  ): string {
    //subscriber id will come from create subscription in case of cloud
    //For local it will be populated like below
    const subscriberId = uuidv4();
    const subscriber: Subscriber = {
      subscriberId: subscriberId,
      entityId: entityId,
      componentIdentifier: componentIdentifier,
      eventType: eventType,
      callback: callback,
    };
    let subcriberList = this.subscribers.get(entityId + eventType);
    if (!subcriberList) {
      subcriberList = new Array<Subscriber>();
    }
    subcriberList.push(subscriber);
    this.subscribers.set(entityId + eventType, subcriberList);
    const pubNubSubscription: PubNubSubscription = {
      id: subscriberId,
      type: eventType,
      aggregator: this.pubNubMessageAggregator,
    };
    this.pubNubHelper.subscribe(pubNubSubscription, subscriber);
    return subscriberId;
  }

  /**
   * To Do Implemented and request will change is next PR
   * unSubscribe to Notification Service
   * @param {subscriberId} The unique Identifier passed when subscription
   * @param {entityId} The unique Identifier
   * @param {context} Cloud or Local
   */
  public unSubscribe(
    _subscriberId: string,
    _entityId: string,
    _context: string
  ): void {
    console.log('Unsubscribed called');
  }

  /**
   * Unsubscribing to all
   */
  public unsubscribeAll(): void {
    this.pubNubHelper.unSubscribeAll();
    this.subscribers = new Map<string, Subscriber[]>();
  }

  /**
   * Publishing Events , this to throw error in future
   */
  public publishEvents(
    _entityId: string,
    _eventType: NotificationType,
    _data: any
  ): void {
    console.log('publish Events Called');
  }

  /**
   * All the messages from pubnum wrapper will directed here
   * @param {Subscriber} subscriber request
   * @param {string}  data published in pub nub
   */
  private pubNubMessageAggregator(
    subscriber: Subscriber,
    payload: string
  ): void {
    if (
      !this.subscribers ||
      !this.subscribers.get(subscriber.entityId + subscriber.eventType)
    ) {
      throw new Error('subscriber not initialized');
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    this.subscribers
      .get(subscriber.entityId + subscriber.eventType)
      .forEach((subscriber, _i) => subscriber.callback(payload));
  }
  /**
   * Check if Notification service is properly Initialized
   * @return {boolean}  flag to represent intialization of service
   */
  public validateInititalization(): boolean {
    return this.isInitialized;
  }
}
