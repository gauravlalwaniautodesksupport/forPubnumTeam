import { IPubNubCredentials } from './model/IPubNubCredentials';
import { Subscriber } from './model/ISubscription';
import PubNub from 'pubnub';
import { PubNubSubscription } from './model/ISubscription';

export class PubNubWrapper {
  private pubnub!: PubNub;
  private channels: string[] = [];
  /**
   * Pubnub initialization
   */
  public initializePuNub(pubNubCredentials: IPubNubCredentials): void {
    const cred ={
      subscribeKey: "test",
      cipherKey: "asdsd",
      uuid: pubNubCredentials.uuid
    }
    this.pubnub = new PubNub(cred);
    this.channels = [];
  }

  /**
   * subscribing to pubnub channels
   */
  public subscribe(
    pubNubSubscription: PubNubSubscription,
    subscriber: Subscriber
  ): void {
    if (!this.pubnub) {
      throw new Error('PubNub is not initialized ');
    }
    this.pubnub.subscribe({
      channels: this.getChannel(),
    });
    this.pubnub.addListener({
      message: (message) => {
        pubNubSubscription.aggregator(subscriber, message.message.update);
      },
    });
  }

  /**
   * UnSubscribing to pubnub channels
   */
  public unSubscribe(): void {
    if (!this.pubnub) {
      throw new Error('PubNub is not initialized ');
    }
    this.pubnub.unsubscribe({
      channels: this.getChannel(),
    });
  }

  /**
   * UnSubscribing to  All pubnub channels
   */
  public unSubscribeAll(): void {
    if (!this.pubnub) {
      throw new Error('PubNub is not initialized ');
    }
    this.pubnub.stop();
  }
  /**
   * ToDo in Next PR once L3 Packages is created
   */
  /**
   * get channel/group name
   */
  public getChannel(): string[] {
    //hard coded for now
    this.channels = ['the_guide'];
    return this.channels;
  }

  public getPubnubCredentials(): IPubNubCredentials {
    const pubNubCred: IPubNubCredentials = {
      subscribeKey: 'sub-c-b495b858-ead1-11eb-be89-3ebc6f27b518',
      uuid: 'UniqueUid',
    };
    return pubNubCred;
  }
}
