import { NotificationContextTypes } from './model/NotificationContextTypes';

import { CloudNotifications } from './CloudNotifications';
import { NotificationType } from './model/INotification';
import { LocalNotifications } from './LocalNotifications';

export class NotificationManager {
  private localNotifications!: LocalNotifications;
  private cloudNotifications!: CloudNotifications;

  constructor() {
    this.localNotifications = new LocalNotifications();
    this.cloudNotifications = new CloudNotifications();
  }

  /**
   * subscribe Notifications of local & cloud
   * @param entityId
   * @param eventType
   * @param callback
   * @param componentIdentifier
   * @param notificationContextType
   */
  public subscribe(
    entityId: string,
    eventType: NotificationType,
    callback: (...args: any) => void,
    componentIdentifier: string,
    notificationContextType: NotificationContextTypes
  ) {
    if (notificationContextType === NotificationContextTypes.CLOUD) {
      if (!this.cloudNotifications.validateInititalization()) {
        this.cloudNotifications.initialize();
      }
      this.cloudNotifications.subscribe(
        entityId,
        eventType,
        callback,
        componentIdentifier
      );
    } else {
      if (!this.localNotifications.validateInititalization()) {
        this.localNotifications.initialize();
      }
      this.localNotifications.subscribe(
        entityId,
        eventType,
        callback,
        componentIdentifier
      );
    }
  }
  /**
   * publish Notification Events from local
   * @param entityId
   * @param eventType
   * @param callback
   * @param componentIdentifier
   * @param notificationContextType
   */
  public publishEvents(
    entityId: string,
    eventType: NotificationType,
    data: any,
    notificationContextType: NotificationContextTypes
  ) {
    if (notificationContextType === NotificationContextTypes.LOCAL) {
      this.localNotifications.publishEvents(entityId, eventType, data);
    } else {
      throw new Error(
        'Notification context is not local: Publish is only allowed for local'
      );
    }
  }

  /**
   * unSubscribeAll Notifications of local & cloud
   */
  public unSubscribeAll() {
    if (this.cloudNotifications.validateInititalization()) {
      this.cloudNotifications.unsubscribeAll();
    }
    this.localNotifications.unsubscribeAll();
  }
}
