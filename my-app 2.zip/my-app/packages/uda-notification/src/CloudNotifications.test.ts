import { CloudNotifications } from './CloudNotifications';
import { NotificationType } from './model/INotification';
import {  Subscriber } from './model/ISubscription';

describe('CloudNotifications', () => {
  const callbackFunction = jest.fn();
  const subscriber: Subscriber = {
    subscriberId: '1',
    eventType: NotificationType.FILES,
    entityId: '123',
    callback: callbackFunction,
    componentIdentifier: '1234',
  };
  it('validate initialize', () => {
    const client = new CloudNotifications();
    const spy = jest.spyOn(client, 'initialize');
    const spy2 = jest.spyOn(client, 'validateInititalization');
    client.validateInititalization();
    expect(spy2).lastReturnedWith(false);
    client.initialize();
    client.validateInititalization();
    expect(spy2).lastReturnedWith(true);
    expect(spy).toBeCalledTimes(1);
    client.unsubscribeAll();
  });

  it('validate subscribe', () => {
    const client = new CloudNotifications();
    jest.spyOn(client, 'initialize');
    client.initialize();
    const spy = jest.spyOn(client, 'subscribe');
    const returnValue = client.subscribe(
      subscriber.entityId,
      subscriber.eventType,
      subscriber.callback,
      subscriber.componentIdentifier
    );
    expect(spy).toBeCalledTimes(1);
    expect(typeof returnValue).toBe('string');
    client.unsubscribeAll();
  });

  it('validate pubnubAggregator, Subscriber is not registered', () => {
    const client = new CloudNotifications();
    jest.spyOn(client, 'initialize');
    client.initialize();
    expect(() => client['pubNubMessageAggregator'](subscriber, 'test')).toThrow(
      'subscriber not initialized'
    );
    client.unsubscribeAll();
  });

  it('validate pubnubAggregator', () => {
    const client = new CloudNotifications();
    const spy = jest.spyOn(client, 'initialize');
    const spy2 = jest.spyOn(client, 'validateInititalization');
    client.initialize();
    client.validateInititalization();
    expect(spy).toBeCalledTimes(1);
    expect(spy2).lastReturnedWith(true);
    jest.spyOn(client, 'subscribe');
    client.subscribe(
      subscriber.entityId,
      subscriber.eventType,
      subscriber.callback,
      subscriber.componentIdentifier
    );
    expect(() =>
      client['pubNubMessageAggregator'](subscriber, 'test')
    ).not.toThrow('subscriber not initialized');
    expect(callbackFunction).toBeCalledTimes(1);
    client.unsubscribeAll();
  });

  it('validate pubnubAggregator after unsubscribed is called', () => {
    const client = new CloudNotifications();
    const spy = jest.spyOn(client, 'initialize');
    const spy2 = jest.spyOn(client, 'validateInititalization');
    client.initialize();
    client.validateInititalization();
    expect(spy).toBeCalledTimes(1);
    expect(spy2).lastReturnedWith(true);
    jest.spyOn(client, 'subscribe');
    client.subscribe(
      subscriber.entityId,
      subscriber.eventType,
      subscriber.callback,
      subscriber.componentIdentifier
    );
    expect(spy).toBeCalledTimes(1);
    expect(() =>
      client['pubNubMessageAggregator'](subscriber, 'test')
    ).not.toThrow('subscriber not initialized');
    client.unsubscribeAll();
    expect(() => client['pubNubMessageAggregator'](subscriber, 'test')).toThrow(
      'subscriber not initialized'
    );
    client.unsubscribeAll();
  });
});
