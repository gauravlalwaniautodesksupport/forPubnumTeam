import { NotificationContextTypes } from './model/NotificationContextTypes';
import { NotificationType } from './model/INotification';
export declare class NotificationManager {
    private localNotifications;
    private cloudNotifications;
    constructor();
    /**
     * subscribe Notifications of local & cloud
     * @param entityId
     * @param eventType
     * @param callback
     * @param componentIdentifier
     * @param notificationContextType
     */
    subscribe(entityId: string, eventType: NotificationType, callback: (...args: any) => void, componentIdentifier: string, notificationContextType: NotificationContextTypes): void;
    /**
     * publish Notification Events from local
     * @param entityId
     * @param eventType
     * @param callback
     * @param componentIdentifier
     * @param notificationContextType
     */
    publishEvents(entityId: string, eventType: NotificationType, data: any, notificationContextType: NotificationContextTypes): void;
    /**
     * unSubscribeAll Notifications of local & cloud
     */
    unSubscribeAll(): void;
}
//# sourceMappingURL=NotificationManager.d.ts.map