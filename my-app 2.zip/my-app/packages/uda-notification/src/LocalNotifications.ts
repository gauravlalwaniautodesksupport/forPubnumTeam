import { NotificationType, INotification} from './model/INotification';
import {  Subscriber } from './model/ISubscription';
import { v4 as uuidv4 } from 'uuid';

export class LocalNotifications implements INotification {
  private isInitialized: boolean;
  private subscribers = new Map<string, Subscriber[]>();
  constructor() {
    this.isInitialized = false;
  }
  /**
   * Initializing  here, For local initialization.
   */
  public initialize() {
    this.isInitialized = true;
  }

  /**
   * subscribe to Notification Service
   * @param {entityId} The unique Identifier
   * @param {eventType} The notification type like files Added, File Modified etc
   * @param {callback} The callback method passed by consumer
   * @param {componentIdentifier} Component unique identifier
   * @return {string} The subscriber id will be returned
   */
  public subscribe(
    entityId: string,
    eventType: NotificationType,
    callback: (...args: any) => void,
    componentIdentifier: string
  ): string {
    //subscriber id will come from create subscription in case of cloud
    //For local it will be populated like below
    const subscriberId = uuidv4();
    const subscriber: Subscriber = {
      subscriberId: subscriberId,
      entityId: entityId,
      componentIdentifier: componentIdentifier,
      eventType: eventType,
      callback: callback,
    };
    let subcriberList = this.subscribers.get(entityId + eventType);
    if (!subcriberList) {
      subcriberList = new Array<Subscriber>();
    }
    subcriberList.push(subscriber);
    this.subscribers.set(entityId + eventType, subcriberList);
    return subscriberId;
  }

  /**
   * To Do Implemented and request will change is next PR
   * unSubscribe to Notification Service
   * @param {subscriberId} The unique Identifier passed when subscription
   * @param {entityId} The unique Identifier
   * @param {context} Cloud or Local
   */
  public unSubscribe(
    _subscriberId: string,
    _entityId: string,
    _context: string
  ): void {
    console.log('Unsubscribed called');
  }

  /**
   * Unsubscribing to all
   */
  public unsubscribeAll(): void {
    this.subscribers = new Map<string, Subscriber[]>();
  }

  /**
   * publish events
   * @param {entityId} The unique Identifier
   * @param {eventType} The notification type like files Added, File Modified etc
   * @param {data} Data to publish
   */
  public publishEvents(
    entityId: string,
    eventType: NotificationType,
    data: any
  ): void {
    if (!this.subscribers || !this.subscribers.get(entityId + eventType)) {
      throw new Error('Cannot publish a event without subscription');
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    this.subscribers
      .get(entityId + eventType)
      .forEach((subscriber, _i) => subscriber.callback(data));
  }
  /**
   * Check if Notification service is properly Initialized
   * @return {boolean}  flag to represent intialization of service
   */
  public validateInititalization(): boolean {
    return this.isInitialized;
  }
}
