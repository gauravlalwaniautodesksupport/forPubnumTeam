import { NotificationContextTypes } from './model/NotificationContextTypes';
import { NotificationType } from './model/INotification';
import { Subscriber } from './model/ISubscription';
import { CloudNotifications } from './CloudNotifications';
import { LocalNotifications } from './LocalNotifications';
import { NotificationManager } from './NotificationManager';

describe('pubSubNotification', (): any => {
  const entityId = 'testId';
  const eventType = NotificationType.FILES;
  const callbackFn = jest.fn();
  const componentIdentifier = 'testComponent';
  let notificationContextType = NotificationContextTypes.CLOUD;
  const data = 'testData';

  it('should subscribe cloud Notifications when context provided is cloud', () => {
    const notificationManagerInstance = new NotificationManager();
    const mockCloudNotificationsSpy = jest
      .spyOn(CloudNotifications.prototype, 'subscribe')
      .mockImplementation(() => 'subscriberId');
    jest.spyOn(CloudNotifications.prototype, 'initialize').mockImplementation();
    notificationManagerInstance.subscribe(
      entityId,
      eventType,
      callbackFn,
      componentIdentifier,
      notificationContextType
    );
    expect(mockCloudNotificationsSpy).toHaveBeenCalledWith(
      entityId,
      eventType,
      callbackFn,
      componentIdentifier
    );
    expect(mockCloudNotificationsSpy).toHaveReturnedWith('subscriberId');
    notificationManagerInstance.unSubscribeAll();
  });

  it('should subscribe local Notifications when context provided is local', () => {
    const notificationManagerInstance = new NotificationManager();
    notificationContextType = NotificationContextTypes.LOCAL;

    const mockLocalNotificationsSpy = jest
      .spyOn(LocalNotifications.prototype, 'subscribe')
      .mockImplementation(() => 'subscriberId');

    notificationManagerInstance.subscribe(
      entityId,
      eventType,
      callbackFn,
      componentIdentifier,
      notificationContextType
    );
    expect(mockLocalNotificationsSpy).toHaveBeenCalledWith(
      entityId,
      eventType,
      callbackFn,
      componentIdentifier
    );
    expect(mockLocalNotificationsSpy).toHaveReturnedWith('subscriberId');
    notificationManagerInstance.unSubscribeAll();
  });

  it('should publish Notification Events when context provided is local', () => {
    const notificationManagerInstance = new NotificationManager();
    const client = new LocalNotifications();
    notificationContextType = NotificationContextTypes.LOCAL;
    const mockSubscriber: Subscriber = {
      subscriberId: 'subscriberId',
      entityId: 'entityId',
      componentIdentifier: 'componentIdentifier',
      eventType: NotificationType.FILES,
      callback: jest.fn(),
    };
    const mockLocalNotificationsSpy = jest.spyOn(client, 'publishEvents');
    client['subscribers'].set(
      mockSubscriber.entityId + mockSubscriber.eventType,
      [mockSubscriber]
    );
    notificationManagerInstance['localNotifications'] = client;
    notificationManagerInstance.publishEvents(
      mockSubscriber.entityId,
      mockSubscriber.eventType,
      data,
      notificationContextType
    );

    expect(mockLocalNotificationsSpy).toBeCalled();
    notificationManagerInstance.unSubscribeAll();
    client.unsubscribeAll();
  });

  it('should not publish Notification Events when context provided is not local & throw error', () => {
    const notificationManagerInstance = new NotificationManager();
    notificationContextType = NotificationContextTypes.CLOUD;
    expect(() =>
      notificationManagerInstance.publishEvents(
        entityId,
        eventType,
        data,
        notificationContextType
      )
    ).toThrow();
    notificationManagerInstance.unSubscribeAll();
  });
});
