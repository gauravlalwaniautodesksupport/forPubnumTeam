export {};
//# sourceMappingURL=LocalNotifications.test.d.ts.map