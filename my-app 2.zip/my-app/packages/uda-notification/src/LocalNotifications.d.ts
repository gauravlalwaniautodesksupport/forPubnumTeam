import { NotificationType, INotification } from './model/INotification';
export declare class LocalNotifications implements INotification {
    private isInitialized;
    private subscribers;
    constructor();
    /**
     * Initializing  here, For local initialization.
     */
    initialize(): void;
    /**
     * subscribe to Notification Service
     * @param {entityId} The unique Identifier
     * @param {eventType} The notification type like files Added, File Modified etc
     * @param {callback} The callback method passed by consumer
     * @param {componentIdentifier} Component unique identifier
     * @return {string} The subscriber id will be returned
     */
    subscribe(entityId: string, eventType: NotificationType, callback: (...args: any) => void, componentIdentifier: string): string;
    /**
     * To Do Implemented and request will change is next PR
     * unSubscribe to Notification Service
     * @param {subscriberId} The unique Identifier passed when subscription
     * @param {entityId} The unique Identifier
     * @param {context} Cloud or Local
     */
    unSubscribe(_subscriberId: string, _entityId: string, _context: string): void;
    /**
     * Unsubscribing to all
     */
    unsubscribeAll(): void;
    /**
     * publish events
     * @param {entityId} The unique Identifier
     * @param {eventType} The notification type like files Added, File Modified etc
     * @param {data} Data to publish
     */
    publishEvents(entityId: string, eventType: NotificationType, data: any): void;
    /**
     * Check if Notification service is properly Initialized
     * @return {boolean}  flag to represent intialization of service
     */
    validateInititalization(): boolean;
}
//# sourceMappingURL=LocalNotifications.d.ts.map