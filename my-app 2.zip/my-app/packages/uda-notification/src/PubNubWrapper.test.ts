import { PubNubWrapper } from './PubNubWrapper';
import {
  PubNubSubscription,
  Subscriber,
} from './model/ISubscription';
import {

  IPubNubCredentials
} from './model/IPubNubCredentials';
import {
  NotificationType
} from './model/INotification';

describe('PubNub Wrapper', () => {
  const pubNubCred: IPubNubCredentials = {
    subscribeKey: 'sub-c-b495b858-ead1-11eb-be89-3ebc6f27b518',
    uuid: 'UniqueUid',
  };
  const callbackFunction = jest.fn();
  const subscriber: Subscriber = {
    subscriberId: '1',
    eventType: NotificationType.FILES,
    entityId: '123',
    callback: callbackFunction,
    componentIdentifier: '1234',
  };
  const punNubSubscription: PubNubSubscription = {
    id: '1',
    type: NotificationType.FILES,
    aggregator: callbackFunction,
  };

  // const channels =['the_guide'];
  it('validate initialize', () => {
    const client = new PubNubWrapper();
    jest.spyOn(client, 'initializePuNub');
    client.initializePuNub(pubNubCred);
    expect(client.initializePuNub).toBeCalledWith(pubNubCred);
  });

  it('validate subscribe (Calling subscribe without initialization of PubNum)', () => {
    const client = new PubNubWrapper();
    jest.spyOn(client, 'unSubscribeAll');
    jest.spyOn(client, 'subscribe');
    expect(() => client.subscribe(punNubSubscription, subscriber)).toThrow(
      'PubNub is not initialized '
    );
    expect(() => client.unSubscribeAll()).toThrow('PubNub is not initialized ');
  });

  it('validate subscribe', () => {
    const client = new PubNubWrapper();
    client.initializePuNub(pubNubCred);
    const spy = jest.spyOn(client, 'subscribe');
    client.subscribe(punNubSubscription, subscriber);
    expect(spy).toBeCalledTimes(1);
    expect(spy).lastReturnedWith(undefined);
    client.unSubscribeAll();
  });

  it('validate unSubscribe', () => {
    const client = new PubNubWrapper();
    client.initializePuNub(pubNubCred);
    const spy = jest.spyOn(client, 'subscribe');
    const spy2 = jest.spyOn(client, 'unSubscribe');
    client.subscribe(punNubSubscription, subscriber);
    expect(spy).toBeCalledTimes(1);
    expect(spy).lastReturnedWith(undefined);
    client.unSubscribe();
    expect(spy2).toBeCalled();
    client.unSubscribeAll();
  });

  it('validate unSubscribe All', () => {
    const client = new PubNubWrapper();
    client.initializePuNub(pubNubCred);
    const spy = jest.spyOn(client, 'subscribe');
    const spy2 = jest.spyOn(client, 'unSubscribeAll');
    client.subscribe(punNubSubscription, subscriber);
    expect(spy).toBeCalledTimes(1);
    expect(spy).lastReturnedWith(undefined);
    client.unSubscribeAll();
    expect(spy2).toBeCalled();
    client.unSubscribeAll();
  });

  it('validate getChannel', () => {
    const client = new PubNubWrapper();
    client.initializePuNub(pubNubCred);
    const result = ['the_guide'];
    const spy = jest.spyOn(client, 'getChannel');
    client.getChannel();
    expect(spy).lastReturnedWith(result);
    client.unSubscribeAll();
  });

  it('validate getPubnubCredentials', () => {
    const client = new PubNubWrapper();
    client.initializePuNub(pubNubCred);
    const result = {
      subscribeKey: 'sub-c-b495b858-ead1-11eb-be89-3ebc6f27b518',
      uuid: 'UniqueUid',
    };
    const spy = jest.spyOn(client, 'getPubnubCredentials');
    client.getPubnubCredentials();
    expect(spy).lastReturnedWith(result);
    client.unSubscribeAll();
  });
});
