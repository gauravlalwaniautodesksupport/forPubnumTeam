export {};
//# sourceMappingURL=NotificationManager.test.d.ts.map