import { IPubNubCredentials } from './model/IPubNubCredentials';
import { Subscriber } from './model/ISubscription';
import { PubNubSubscription } from './model/ISubscription';
export declare class PubNubWrapper {
    private pubnub;
    private channels;
    /**
     * Pubnub initialization
     */
    initializePuNub(pubNubCredentials: IPubNubCredentials): void;
    /**
     * subscribing to pubnub channels
     */
    subscribe(pubNubSubscription: PubNubSubscription, subscriber: Subscriber): void;
    /**
     * UnSubscribing to pubnub channels
     */
    unSubscribe(): void;
    /**
     * UnSubscribing to  All pubnub channels
     */
    unSubscribeAll(): void;
    /**
     * ToDo in Next PR once L3 Packages is created
     */
    /**
     * get channel/group name
     */
    getChannel(): string[];
    getPubnubCredentials(): IPubNubCredentials;
}
//# sourceMappingURL=PubNubWrapper.d.ts.map