import { LocalNotifications } from './LocalNotifications';
import { NotificationType} from './model/INotification';
import {  Subscriber } from './model/ISubscription';

describe('LocalNotifications', () => {
  const client = new LocalNotifications();
  const callbackFunction = jest.fn();
  const subscriber: Subscriber = {
    subscriberId: '1',
    eventType: NotificationType.FILES,
    entityId: '123',
    callback: callbackFunction,
    componentIdentifier: '1234',
  };
  it('validate initialize', () => {
    const spy = jest.spyOn(client, 'initialize');
    const spy2 = jest.spyOn(client, 'validateInititalization');
    client.validateInititalization();
    expect(spy2).lastReturnedWith(false);
    client.initialize();
    client.validateInititalization();
    expect(spy2).lastReturnedWith(true);
    expect(spy).toBeCalledTimes(1);
  });

  it('validate subscribe', () => {
    const spy = jest.spyOn(client, 'subscribe');
    const returnValue = client.subscribe(
      subscriber.entityId,
      subscriber.eventType,
      subscriber.callback,
      subscriber.componentIdentifier
    );
    expect(spy).toBeCalledTimes(1);
    expect(typeof returnValue).toBe('string');
  });

  it('validate publish Subscriber not registered', () => {
    jest.spyOn(client, 'publishEvents');
    expect(() =>
      client.publishEvents(
        subscriber.entityId + '123',
        subscriber.eventType,
        'test'
      )
    ).toThrow('Cannot publish a event without subscription');
  });

  it('validate publish', () => {
    const spy = jest.spyOn(client, 'publishEvents');
    client.publishEvents(subscriber.entityId, subscriber.eventType, 'test');
    expect(spy).toBeCalledTimes(1);
    expect(spy).toBeCalledWith('123', 'files', 'test');
  });

  it('validate publish after unSubscribeAll', () => {
    const spy = jest.spyOn(client, 'publishEvents');
    client.publishEvents(subscriber.entityId, subscriber.eventType, 'test');
    expect(spy).toBeCalledTimes(1);
    expect(spy).toBeCalledWith('123', 'files', 'test');
    client.unsubscribeAll();
    expect(() =>
      client.publishEvents(
        subscriber.entityId + '123',
        subscriber.eventType,
        'test'
      )
    ).toThrow('Cannot publish a event without subscription');
  });

  afterAll(() => {
    client.unsubscribeAll();
  });
});
