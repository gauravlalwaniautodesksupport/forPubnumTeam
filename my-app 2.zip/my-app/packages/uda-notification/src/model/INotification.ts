export enum NotificationType {
  LOCAL = 'local',
  HUB = 'hub',
  PROJECT = 'project',
  FILES = 'files',
  OTHERS = 'others',
}

/**
 * Notification payload format
 * to be changed in future
 */
export interface NotificationPayload {
  id: string;
  payload: any;
  category: NotificationType;
}

/**
 * Suscriber
 */

export abstract class INotification {
  /**
   * To initialize the INotification instance
   */
  public abstract initialize(): void;
  /**
   * subscribe to Notification Service
   * @param {entityId} The unique Identifier
   * @param {eventType} The notification type like files Added, File Modified etc
   * @param {callback} The callback method passed by consumer
   * @param {componentIdentifier} Component unique identifier
   * @return {string} The subscriber id will be returned
   */
  public abstract subscribe(
    entityId: string,
    eventType: NotificationType,
    callback: (...args) => void,
    componentIdentifier: string
  ): string;

  /**
   * To Do Implemented and request will change is next PR
   * unSubscribe to Notification Service
   * @param {subscriberId} The unique Identifier passed when subscription
   * @param {entityId} The unique Identifier
   * @param {context} Cloud or Local
   */
  public abstract unSubscribe(
    subscriberId: string,
    entityId: string,
    context: string
  ): void;

  /**
   * Unsubscribing to all
   */
  public abstract unsubscribeAll(): void;

  /**
   * publish events
   * @param {entityId} The unique Identifier
   * @param {eventType} The notification type like files Added, File Modified etc
   * @param {data} Data to publish
   */
  public abstract publishEvents(
    entityId: string,
    eventType: NotificationType,
    data: any
  ): void;
  /**
   * Check if Notification service is properly Initialized
   * @return {boolean}  flag to represent intialization of service
   */
  public abstract validateInititalization(): boolean;
}
