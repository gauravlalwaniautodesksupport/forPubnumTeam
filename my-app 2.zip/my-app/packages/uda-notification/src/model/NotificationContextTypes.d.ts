/**
 * All supported NotificationContextTypes
 */
export declare enum NotificationContextTypes {
    CLOUD = "cloud",
    LOCAL = "local"
}
//# sourceMappingURL=NotificationContextTypes.d.ts.map