/**
 * Supported Protocal for UDA Notification
 * For PubNub - WSS will be used
 */
export enum Protocol {
  WSS = 'WSS',
  HTTPS = 'HTTPS',
}
