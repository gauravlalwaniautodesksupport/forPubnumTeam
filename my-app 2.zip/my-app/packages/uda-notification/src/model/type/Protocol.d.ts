/**
 * Supported Protocal for UDA Notification
 * For PubNub - WSS will be used
 */
export declare enum Protocol {
    WSS = "WSS",
    HTTPS = "HTTPS"
}
//# sourceMappingURL=Protocol.d.ts.map