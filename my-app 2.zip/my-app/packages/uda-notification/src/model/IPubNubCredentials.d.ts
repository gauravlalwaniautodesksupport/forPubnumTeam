/**
 * Interface for PubNub Credentials
 * To be changed in once get Subscription is integrated
 */
export interface IPubNubCredentials {
    publishKey?: string;
    subscribeKey?: string;
    uuid: string;
}
//# sourceMappingURL=IPubNubCredentials.d.ts.map