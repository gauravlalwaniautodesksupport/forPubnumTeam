import { Protocol } from './type/Protocol';
import { NotificationType } from './INotification';
/**
 * Notifications Get  Subcription Request
 */
export declare type SubscriptionRequest = {
    entityUrn: string;
    eventType: string;
    permissionResourceIds: string[];
    protocol: Protocol;
    timeToLive: number;
    filters?: string[];
    callbackUrl?: string;
    hookAttribute?: Map<string, string>;
    hookToken?: string;
    channel?: string;
};
/**
 * Notifications   Subcription Request to l3
 */
export declare type Subscription = {
    subscriptionId: string;
    entityUrn: string;
    eventType: string;
    protocol: string;
    filters: string[];
    channel: string;
    callbackUrl?: string;
    hookToken?: string;
    created: string;
    createdBy: string;
    clientId: string;
    updated: string;
    updatedBy: string;
    userId: string;
    timeToLive: number;
};
/**
 * PubNub subscription request
 */
export interface PubNubSubscription {
    id: string;
    type: NotificationType;
    aggregator: (subscriber: Subscriber, payload: string) => void;
}
export interface Subscriber {
    subscriberId: string;
    entityId: string;
    componentIdentifier: string;
    eventType: NotificationType;
    callback: (...args: any[]) => void;
}
export interface Subscribers {
    [propName: string]: Subscriber[];
}
//# sourceMappingURL=ISubscription.d.ts.map