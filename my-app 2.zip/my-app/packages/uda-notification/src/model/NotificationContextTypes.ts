/**
 * All supported NotificationContextTypes
 */
export enum NotificationContextTypes {
  CLOUD = 'cloud',
  LOCAL = 'local',
}
