module.exports = {
  "presets": [
  	["@babel/env", {
  		targets: {
  			esmodules: true
  		}
  	}],
  	["@babel/react"]
  ],
  "env": {
	  "test": {
	    "plugins": [
	      [
	        "@babel/transform-runtime",
	        {
	          "regenerator": true
	        }
	      ],
	      "@babel/plugin-syntax-dynamic-import"
	    ],
	    "presets": [
		  	["@babel/env", {
		  		targets: {
		  			esmodules: true
		  		}
		  	}],
		  	["@babel/react"]
		  ],
	  }
	}
}