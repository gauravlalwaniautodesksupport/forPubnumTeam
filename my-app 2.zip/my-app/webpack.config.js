const { CleanWebpackPlugin } = require('clean-webpack-plugin');
const IgnoreNotFoundExportPlugin = require('ignore-not-found-export-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer')
  .BundleAnalyzerPlugin;
const path = require('path');

// Note: defined here because it will be used more than once.
const cssFilename = 'static/css/[name].[contenthash:8].css';

module.exports = ({ entries, tsInclude } = {}) => ({
  mode: 'production',
  entry: entries || [path.resolve(process.cwd(), 'index.ts')],
  externals: {
    react: 'React',
    'react-dom': 'ReactDOM',
    redux: 'Redux',
    'react-redux': 'ReactRedux',
  },
  plugins: [
    new CleanWebpackPlugin({
      output: {
        path: path.resolve(process.cwd(), 'dist'),
      },
    }),
    new IgnoreNotFoundExportPlugin({
      include: [/\.tsx?$/],
    }),
    new MiniCssExtractPlugin({
      filename: cssFilename,
    }),
    new BundleAnalyzerPlugin({ analyzerMode: 'static', openAnalyzer: false }),
  ],
  target: 'web',
  devtool: 'inline-source-map',
  context: path.resolve(process.cwd(), 'src'),
  resolve: {
    mainFields: ['browser', 'module', 'main'],
    extensions: ['.tsx', '.ts', '.js', '.svg'],
    modules: ['../../node_modules', 'node_modules'],
    fallback: { os: false },
  },
  module: {
    rules: [
      {
        test: /\.tsx?$/,
        include: tsInclude || [path.resolve(process.cwd(), 'src')],
        exclude: [/test\.tsx?$/],
        use: {
          loader: 'ts-loader',
        },
      },
      {
        test: /\.css?$/,
        exclude: [],
        use: [
          {
            loader: MiniCssExtractPlugin.loader,
          },
          'css-loader',
        ],
      },
    ],
  },
  optimization: {
    splitChunks: {
      chunks: 'all',
      minChunks: 3,
      cacheGroups: {
        commons: {
          test: /[\\/]node_modules[\\/]/,
          name: 'vendors',
          chunks: 'all',
        },
        defaultVendors: {
          enforce: true,
        },
        default: {
          minChunks: 2,
          priority: -20,
          reuseExistingChunk: true,
        },
      },
    },
  },
});
