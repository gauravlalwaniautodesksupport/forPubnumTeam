const path = require('path');
const fs = require('fs');

const here = fs.realpathSync(process.cwd());
const srcDir = path.resolve(here, "src");
const appModulesDir = path.resolve(here, "node_modules");
const nodeModules = ["../../node_modules", "node_modules", appModulesDir];
const { CleanWebpackPlugin } = require(path.resolve(appModulesDir, 'clean-webpack-plugin'));
const HtmlWebpackPlugin = require(path.resolve(appModulesDir, 'html-webpack-plugin'));
const minimist = require('minimist');
// const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;
const _argvs = minimist(process.argv.slice(2));
console.info(_argvs);

// This is common configs for development / productions
// For special configs, please add in each package config folder
//
module.exports = ({pageTitle, esTarget, checkType} = {}) => {
  let outputFileName = 'bundle.[hash].js';
  let outputPath = path.resolve(here, 'build');
  let devtool = 'cheap-module-source-map';

  let mode = _argvs.mode || 'development';
  console.info('webpack mode is:' + mode);

  if (mode === 'production') {
    outputPath = path.resolve(here, 'dist');
    devtool = 'source-map';
  }
  let indexHtmlPath = path.resolve(here, '../../config/index.html');
  let htmlVariables = { pageTitle: pageTitle };
  let compileTarget = esTarget === undefined ? 'es5' : esTarget;
  let transpileOnly = checkType === undefined ? true : !checkType;

  return {
    mode: mode,
    // Please refer to https://webpack.js.org/configuration/devtool/
    devtool: devtool,
    // Set current working directory
    context: here,
    target: "web",
    entry: [
      path.resolve(srcDir, 'index.tsx'),
    ],
    resolve: {
      mainFields: ["browser", "module", "main"],
      // Add `.ts` and `.tsx` as a resolvable extension.
      extensions: [".ts", ".tsx", ".js"],
      modules: nodeModules,
      alias: {
        'react': path.resolve(here, './node_modules/react'),
        'react-dom': path.resolve(here, './node_modules/react-dom'),
        'lodash': path.resolve(here, './node_modules/lodash')
      }
    },
    module: {
      rules: [
        {
          test: /\.(js|jsx|mjs)$/,
          loader: 'babel-loader',
          exclude: /node_modules/,
          options: {
            compact: false,
            presets: ['@babel/preset-env'],
            plugins: ['@babel/plugin-proposal-object-rest-spread'],
          },
        },
        {
          test: /\.tsx?$/,
          use: [
            {
              loader: "ts-loader",
              options: {
                // disable type checker - we will use it in fork plugin
                transpileOnly: transpileOnly,
                compilerOptions: {
                  target: compileTarget,
                  declarationMap: false
                }
              },
            }
          ]
        },
        // "css" loader resolves paths in CSS and adds assets as dependencies.
        // "style" loader turns CSS into JS modules that inject <style> tags.
        // In production, we use a plugin to extract that CSS to a file, but
        // in development "style" loader enables hot editing of CSS.
        {
          test: /\.css$/,
          use: [
            'style-loader',
            {
              loader: 'css-loader',
              options: {
                importLoaders: 1,
              },
            }
          ],
        },
        {
          test: /\.(woff(2)?|ttf|eot)(\?v=\d+\.\d+\.\d+)?$/,
          use: [
            {
              loader: 'file-loader',
              options: {
                name: '[name].[ext]',
                outputPath: 'fonts/'
              }
            }
          ]
        }
      ]
    },
    output: {
      filename: outputFileName,
      path: outputPath
    },
    plugins: [
      // new BundleAnalyzerPlugin(),
      new CleanWebpackPlugin(),
      // Makes some environment variables available in index.html.
      // The public URL is available as %PUBLIC_URL% in index.html, e.g.:
      // <link rel="shortcut icon" href="%PUBLIC_URL%/favicon.ico">
      // In production, it will be an empty string unless you specify "homepage"
      // in `package.json`, in which case it will be the pathname of that URL.
      // new InterpolateHtmlPlugin(htmlVariables),
      new HtmlWebpackPlugin({
        ...htmlVariables,
        inject: true,
        template: indexHtmlPath
      })
    ],
    // Some libraries import Node modules but don't use them in the browser.
    // Tell Webpack to provide empty mocks for them so importing them works.
    node: {
      dgram: 'empty',
      fs: 'empty',
      net: 'empty',
      tls: 'empty',
      child_process: 'empty',
    }
  };
};
