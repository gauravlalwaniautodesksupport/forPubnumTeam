const path = require('path');
const fs = require('fs');

const replaceHolder1 = "{{__example__}}";
const replaceHolder2 = "{{__Example__}}";

class CopyExamplePackage {
  constructor() {
    this.srcExampleFolder = path.resolve(__dirname, 'example');
    console.log(this.srcExampleFolder);
    const packagesDir = path.resolve(path.dirname(__dirname), 'packages');
    console.log(packagesDir);
    if (process.argv.length >= 3) {
      this.packageName = process.argv[2];
    } else {
      this.packageName = "cdeexample";
    }
    console.log(this.packageName);
    this.targetDir = path.resolve(packagesDir, this.packageName);
    console.log(this.targetDir);
    
    // keep the copied names here
    this.copiedNames = [];
  }

  // copy example package folder to target package folder
  copyExamplePackage() {
    this.copyDir(this.srcExampleFolder, this.targetDir);
    //console.log(this.copiedNames);
  }

  mkdirsSync(dirname) {
    if (fs.existsSync(dirname)) {
      return true;
    } else {
      if (this.mkdirsSync(path.dirname(dirname))) {
        console.log("mkdirsSync = " + dirname);
        fs.mkdirSync(dirname);
        return true;
      }
    }
  }

  _copy(srcName, distName) {
    let paths = fs.readdirSync(srcName)
    const self = this;
    paths.forEach(function(subName) {
      let _srcName = srcName + '/' + subName;
      let _distName = distName + '/' + subName;
      const stat = fs.statSync(_srcName);
      if(stat.isFile()) {
        fs.writeFileSync(_distName, fs.readFileSync(_srcName));
        console.log("Copied file ", _srcName, " to ", _distName);
        self.copiedNames.push(_distName);
      } else if(stat.isDirectory()) {
        self.copyDir(_srcName, _distName);
      }
    });
  }

  copyDir(srcFolder, targetFoder) {
    const b = fs.existsSync(targetFoder);
    console.log("Copy data to folder :" + targetFoder);
    if(!b) {
      console.log("create folder : ",targetFoder);
      this.mkdirsSync(targetFoder);
    }
    this._copy(srcFolder, targetFoder);
  }

  replaceContent() {
    const replaceStr1 = this.packageName.toLowerCase();
    let replaceStr2 = replaceStr1;
    replaceStr2 = replaceStr2.replace(replaceStr2[0], replaceStr2[0].toUpperCase());
    this.copiedNames.forEach( (fullPathFile) => {
      const data = fs.readFileSync(fullPathFile);
      
      let str = data.toString();
      str = str.replace( new RegExp(replaceHolder1, 'g'), replaceStr1);
      str = str.replace( new RegExp(replaceHolder2, 'g'), replaceStr2);

      fs.writeFileSync(fullPathFile, str);
      console.log("Replaced data replace_holder for file ", fullPathFile);
    });
  }
}

if (process.argv.length >= 3) {
  const packageName = process.argv[2];
  console.log("The creating package name is ", packageName);
} else {
  console.error("There is no package name parameters, please run command like below:\n npm run create_pakage my_project");
  return;
}

const copyExampleObj = new CopyExamplePackage();
copyExampleObj.copyExamplePackage();
copyExampleObj.replaceContent();
