/**
 * Tests for {{__Example__}} App
 */
import { Mediator } from '@adsk/cde-mediator';
import { Client, MockClient } from '@adsk/fusion-hostapi';
import { mount } from 'enzyme';
import React from 'react';
import { Provider } from 'react-redux';
import { Store } from 'redux';
import ConnectedApp from './App';
import { onSetMockData } from './GeneratedMocks';

async function sleep(sec: number) {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve('');
        }, sec * 1000);
    });
}

describe('{{__Example__}} App Test', (): any => {
    let hostSdk: Client;
    let mediator: Mediator;
    let store: Store;

    beforeEach(() => {
        hostSdk = new MockClient();
        onSetMockData(hostSdk);
        mediator = new Mediator();
        store = mediator.getStore();
    });

    it('Render {{__Example__}} Table', async () => {
        expect.assertions(1);
        const renderedApp = mount(
            <Provider store={store}>
                <ConnectedApp hostSdk={hostSdk} />
            </Provider>
        );
        await sleep(0.5);
        renderedApp.update();

        expect(renderedApp.find('Connect(App)')).toHaveLength(1);
    });
});
