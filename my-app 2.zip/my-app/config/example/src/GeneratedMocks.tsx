/**
 * Function for generating mocks of forge appfw dependencies
 */
import { Client, ICDEConfig } from '@adsk/fusion-hostapi';

const MockCDEConfig: ICDEConfig = {
    inputData: {
        pimProductAssetUrn: 'pimProductAssetUrn',
        snapshotUrn: 'snapshotUrn',
        lineageUrn: 'lineageUrn',
        versionUrn: 'versionUrn'
    },
    commonConfig: {
        'ft-manage-extension': 'false'
    },
    featureConfig: {}
};

const onSetMockData = (client: Client) => {
    const hostSdk: Client = client;
    const mockNeutronObject: any = hostSdk.getNeutronJavascriptObject();
    mockNeutronObject.addMockCDEConfig(MockCDEConfig);
};

export { onSetMockData };
