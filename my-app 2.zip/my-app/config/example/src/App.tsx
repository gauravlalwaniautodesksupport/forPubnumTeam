import { IMediator, Mediator } from '@adsk/cde-mediator';
import { BaseApp } from '@adsk/fusion-cde-base-app';
import { ICDEConfig } from '@adsk/fusion-hostapi';

import * as React from 'react';
import { connect } from 'react-redux';

const mediator: IMediator = new Mediator();

export class App extends BaseApp {
    private featureToggles: any;
    private commonConfig: any;
    private inputData: any;

    constructor(props: any) {
        super(props, mediator, 'cde-{{__example__}}');
        this.state = {
            isLoaded: false
        };
    }

    public componentDidUpdate(prevProps) {
        // add corresponding implementation here
    }

    public render(): React.ReactNode {
        const divStyle: any = {
            display: 'flex',
            flexFlow: 'column',
            minHeight: '200px',
            minWidth: '200px',
            height: '100vh'
        };

        const tableStyle: any = {
            flex: 1
        };

        return (
            <div style={divStyle}>
                <div style={tableStyle}>
                    <p>This is the sample information, please add your new feature here</p>
                    <p>inputData is {JSON.stringify(this.inputData)}</p>
                    <p>commonConfig is {JSON.stringify(this.commonConfig)}</p>
                    <p>featureToggles is {JSON.stringify(this.featureToggles)}</p>
                </div>
            </div>
        );
    }

    protected onInitConfig(res: ICDEConfig): void {
        this.featureToggles = res.featureConfig;
        this.commonConfig = res.commonConfig;
        this.inputData = res.inputData;

        this.setState({
            isLoaded: true
        });
    }
}

const mapStateToThis = (state) => {
    const propertiesState = state['@adsk/cde-{{__example__}}'];
    const tableState = propertiesState ? propertiesState.propertiesTableState : undefined;
    return {
        tableState: tableState
    };
};

export default connect(mapStateToThis)(App);
