/**
 * Integration Test for {{__Example__}} App
 */
import { Mediator } from '@adsk/cde-mediator';
import { Client, MockClient } from '@adsk/fusion-hostapi';
import { mount } from 'enzyme';
import React from 'react';
import { Provider } from 'react-redux';
import { Store } from 'redux';
import ConnectedApp from './App';
import { onSetMockData } from './GeneratedMocks';

async function sleep(sec: number) {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve('');
        }, sec * 1000);
    });
}

describe('Integration {{__Example__}} App Test', () => {
    let hostSdk: Client;
    let mediator: Mediator;
    let store: Store;

    beforeEach(() => {
        hostSdk = new MockClient();
        onSetMockData(hostSdk);
        mediator = new Mediator();
        store = mediator.getStore();
    });

    it('should render {{__Example__}} table successfully', async () => {
        const renderedApp = mount(
            <Provider store={store}>
                <ConnectedApp hostSdk={hostSdk} />
            </Provider>
        );

        await sleep(0.5);
        renderedApp.update();
        expect(renderedApp.find('App')).toHaveLength(1);
    });
});
