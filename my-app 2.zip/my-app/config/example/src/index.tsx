import { IMediator, Mediator } from '@adsk/cde-mediator';
import { AppUtil } from '@adsk/fusion-cde-base-app';
import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { Provider } from 'react-redux';

import App from './App';
import { onSetMockData } from './GeneratedMocks';

const mediator: IMediator = new Mediator();

AppUtil.initHostApp(
    (rootElement, client) => {
        ReactDOM.render(
            <Provider store={mediator.getStore()}>
                <App hostSdk={client} />
            </Provider>,
            rootElement
        );
    },
    async (client) => {
        onSetMockData(client);
    }
);
