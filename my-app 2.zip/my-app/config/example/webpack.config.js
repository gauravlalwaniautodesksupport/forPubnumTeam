const merge = require('webpack-merge');
const commonConfig = require('../../config/webpack.common');

const WarningsToErrorsPlugin = require('warnings-to-errors-webpack-plugin');

// Common Host app configs
const baseConfigs = commonConfig({
  pageTitle: '{{__Example__}}'
});

// Add extra configs at below
module.exports = merge(baseConfigs, {
  plugins: [
    new WarningsToErrorsPlugin(),
  ],
});

