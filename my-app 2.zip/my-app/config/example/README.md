{{__Example__}}
=======================

For Fremont integration usage