import { AppUtil } from '@adsk/fusion-cde-base-app';

AppUtil.initInterfaceTesting();
