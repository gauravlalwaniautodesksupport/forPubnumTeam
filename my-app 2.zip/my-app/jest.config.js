module.exports = {
    coverageReporters: [
      "html",
      "cobertura"
    ],
    collectCoverageFrom: [
      "(src|packages)/**/*.{ts,tsx,js,jsx}",
      "!packages/**/index.ts",
      "!packages/**/index.tsx",
      "!packages/**/webpack.config.js",
      "!packages/**/config/webpack.config.*.js",
      "!<rootDir>/**/node_modules/**/*",
      "!packages/**/docs/**/*",
      "!packages/**/(build|build3p|dist)/**/*",
      "!packages/test/**/*",
      "!packages/fusion-hostapi/src/it/*.{ts,tsx,js,jsx}",
      "!packages/fusion-content-panel/src/utilities/*.{ts,tsx,js,jsx}"
    ],

    coveragePathIgnorePatterns: [
      "<rootDir>/src/",
      "packages/uda-automation/"
    ],
    setupFilesAfterEnv: [
      "<rootDir>/src/setupTests.ts"
    ],
    testMatch: [
      "<rootDir>/packages/**/src/**/__tests__/**/*.(j|t)s?(x)",
      "<rootDir>/packages/**/src/**/*.(spec|test).(j|t)s?(x)"
    ],
    testURL: "http://localhost",
    transform: {
      "^.+\\.(tsx|jsx|ts|js)?$": "<rootDir>/scripts/jest/typescriptTransform.js",
      "^.+\\.css$": "<rootDir>/scripts/jest/cssTransform.js",
      "^(?!.*\\.(js|jsx|mjs|css|json)$)": "<rootDir>/scripts/jest/fileTransform.js",
    },
    transformIgnorePatterns: [
      // After CDE-components transpiled to es5, we can remove cde entries listed below
      "/node_modules/(?!(@adsk/cde-.*|@adsk/uda-.*|react-base-table)/)",
    ],
    moduleDirectories: [
      "node_modules",
      // Add each app's module path to support React hooks which requries same version Rect libs.
      "<rootDir>/packages/../node_modules"
    ],
    moduleFileExtensions: [
      "ts",
      "tsx",
      "js",
      "jsx",
      "json",
      "node",
      "mjs"
    ],
    "snapshotSerializers": [
      "enzyme-to-json/serializer"
    ],
    globals: {
      "ts-jest": {
        "tsConfig": "<rootDir>/tsconfig.test.json",
        "isolatedModules": true
      },
    },
    "setupFiles": ["jest-canvas-mock"]
}
